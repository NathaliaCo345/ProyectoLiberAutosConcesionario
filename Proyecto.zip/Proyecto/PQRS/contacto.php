<?php

include("conexion.php");

if (isset($_POST['contact'])) {
    if (
        strlen($_POST['name']) >= 1 && 
        strlen($_POST['telefono']) >= 1 && 
        strlen($_POST['direccion']) >= 1 && 
        strlen($_POST['tipoSolicitud']) >= 1 && 
        strlen($_POST['mensaje']) >= 1 
        ) {
            $name = trim($_POST['name']);
            $telefono = trim($_POST['telefono']);
            $direccion = trim($_POST['direccion']);
            $tipoSolicitud = trim($_POST['tipoSolicitud']);
            $mensaje =trim($_POST['mensaje']);
            $fecha =date("d/m/y");
            $consulta = "INSERT INTO datos(nombre, telefono, direccion, tipoSolicitud, mensaje, fecha)
            VALUES ('$name, '$telefono', '$direccion', '$tipoSolicitud ', '$mensaje', '$fecha')";
            $resultado = mysqli_query($conexion, $consulta);
            if ($resultado) {
                ?>
                    <h3 class="sucess">Tu registro se a completado</h3>
                <?php
            }else {
                ?>
                    <h3 class="error">Ocurrio un error</h3>
                <?php
            }
    } else { ?> <h3 class="error">Llena todos los campos</h3> <?php }
}
?>