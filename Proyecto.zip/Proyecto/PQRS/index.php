<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PRQS</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="form-container">
        <h2>PRQS</h2>
        <p> 
            Deja tu Peticion, Queja, Reclamo o Sugerencia.
        </p>
        <form method= "post" autocomplete="off">

            <div class="form-group">

                <div class="form-content">
                    <label for="name">Nombre</label>
                    <input type="text" id="name" name="name" placeholder="Nombre">
                </div>

                <div class="form-content">
                    <label for="telefono">Telefono</label>
                    <input type="text" id="telefono" name="telefono" placeholder="Telefono">
                </div>

                <div class="form-content">
                    <label for="direccion">Direccion</label>
                    <input type="text" id="direccion" name="direccion" placeholder="Direccion">
                </div>

                <div class="form-content">
                    <label for="tipoSolicitud">Tipo de solicitud</label>
                    <input type="text" id="tipoSolicitud" name="tipoSolicitud" placeholder="Tipo de solicitud">
                </div>
            </div>

            <label for="mensaje"> Mensaje</label>
            <textarea name="mensaje" id="mensaje" cols="30" rows="10" pacleholders="Mensaje"></textarea>

            <input class="btn" type="submit" name="Boton" value="Enviar Mensaje">
        </form>
    </div>   

    <?php
        include("contacto.php")
    ?>

</body>
</html>